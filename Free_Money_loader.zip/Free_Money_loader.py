import socket

def server():
    host = '0.0.0.0'  # Listen on all interfaces
    port = 9999       # Port to listen on

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(1)
    print(f"Listening on {host}:{port}...")

    conn, addr = s.accept()
    print(f"Connection from {addr}")

    while True:
        command = input("Shell> ")
        if command.lower() == 'exit':
            conn.send(b'exit')
            break
        if len(command.strip()) == 0:
            continue
        conn.send(command.encode())
        data = conn.recv(4096).decode()
        print(data)

    conn.close()
    s.close()

if __name__ == "__main__":
    server()
